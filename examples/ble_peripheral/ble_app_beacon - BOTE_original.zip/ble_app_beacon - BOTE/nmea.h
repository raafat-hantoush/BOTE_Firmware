#ifndef NMEA__H
#define NMEA__H


unsigned char nmea_parser( char* buf );

#endif
